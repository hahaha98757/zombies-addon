package com.github.stachelbeere1248.zombiesutils.utils;

public class ScoardboardException extends Exception {
    public ScoardboardException() {
    }
}
