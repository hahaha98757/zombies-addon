package com.github.stachelbeere1248.zombiesutils.game.enums;

public enum Difficulty {
    NORMAL, HARD, RIP
}
