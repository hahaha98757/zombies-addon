package xyz.stachel.zombiesutils.game.enums;

public enum Difficulty {
    NORMAL, HARD, RIP
}
