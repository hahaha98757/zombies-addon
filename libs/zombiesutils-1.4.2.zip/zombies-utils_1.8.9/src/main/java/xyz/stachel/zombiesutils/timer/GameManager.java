package xyz.stachel.zombiesutils.timer;

import xyz.stachel.zombiesutils.game.enums.Difficulty;
import xyz.stachel.zombiesutils.game.enums.Map;
import xyz.stachel.zombiesutils.utils.InvalidMapException;
import xyz.stachel.zombiesutils.utils.ScoardboardException;
import xyz.stachel.zombiesutils.utils.Scoreboard;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Optional;
import java.util.Set;

public class GameManager {
    private final HashMap<String, Game> GAMES;

    public GameManager() {
        GAMES = new HashMap<>();
    }

    public Optional<Game> getGame() {
        return Scoreboard.getServerNumber().map(GAMES::get);
    }

    public void endGame(final String serverNumber, final boolean isWin) {
        if (!GAMES.containsKey(serverNumber)) return;
        final Game game = GAMES.get(serverNumber);
        if (isWin) {
            switch (game.getGameMode().getMap()) {
                case DEAD_END:
                case BAD_BLOOD:
                case PRISON:
                    game.pass(30);
                    break;
                case ALIEN_ARCADIUM:
                    game.pass(105);
                    break;
            }
        }
        GAMES.remove(serverNumber);

    }

    public void splitOrNew(int round) throws ScoardboardException, InvalidMapException {
        final String serverNumber = Scoreboard.getServerNumber().orElseThrow(ScoardboardException::new);
        if (GAMES.containsKey(serverNumber)) {
            if (round == 0) newGame(serverNumber);
            else GAMES.get(serverNumber).pass(round);
        } else newGame(serverNumber);
    }

    private void newGame(@NotNull String serverNumber) throws InvalidMapException {
        final Game game = new Game(Map.getMap().orElseThrow(InvalidMapException::new), serverNumber);
        this.GAMES.put(serverNumber, game);
    }

    public Set<String> getGames() {
        return this.GAMES.keySet();
    }

    public void killAll() {
        GAMES.clear();
    }

}
