package xyz.stachel.zombiesutils.utils;

public class InvalidMapException extends Exception {
}
