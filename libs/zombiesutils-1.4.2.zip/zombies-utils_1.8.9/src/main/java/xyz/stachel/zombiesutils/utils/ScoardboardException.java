package xyz.stachel.zombiesutils.utils;

public class ScoardboardException extends Exception {
    public ScoardboardException() {
    }
}
