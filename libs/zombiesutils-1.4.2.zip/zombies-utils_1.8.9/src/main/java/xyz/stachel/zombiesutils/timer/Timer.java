package xyz.stachel.zombiesutils.timer;

public class Timer {

    private static long globalTickCounter = 0;

    public static void runTick() {
        globalTickCounter += 1;
    }

    private long startTick;
    private int roundStart;

    public Timer() {
        this.startTick = Timer.globalTickCounter;
    }

    public void correctStartTick() {
        this.startTick = Timer.globalTickCounter - 200;
    }

    void split() {
        this.roundStart = this.getGameTime();
    }

    public int getGameTime() {
        return (int) (Timer.globalTickCounter - startTick);
    }

    public short getRoundTime() {
        return (short) (getGameTime() - roundStart);
    }

}
