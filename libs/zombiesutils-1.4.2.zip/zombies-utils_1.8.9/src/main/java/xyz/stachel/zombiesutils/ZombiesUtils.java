package xyz.stachel.zombiesutils;

import xyz.stachel.zombiesutils.commands.CommandRegistry;
import xyz.stachel.zombiesutils.config.Hotkeys;
import xyz.stachel.zombiesutils.config.ZombiesUtilsConfig;
import xyz.stachel.zombiesutils.game.GameData;
import xyz.stachel.zombiesutils.handlers.Handlers;
import xyz.stachel.zombiesutils.timer.GameManager;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;

@Mod(modid = "zombiesutils", useMetadata = true, clientSideOnly = true, guiFactory = "xyz.stachel.zombiesutils.config.GuiFactory")
public class ZombiesUtils {
    private static ZombiesUtils instance;
    private final Hotkeys hotkeys;
    private final GameManager gameManager;
    private ZombiesUtilsConfig config;
    private Handlers handlers;
    private Logger logger;
    private GameData gameData;

    public ZombiesUtils() {
        hotkeys = new Hotkeys();
        gameManager = new GameManager();

        instance = this;
    }

    public static ZombiesUtils getInstance() {
        return instance;
    }

    public static boolean isHypixel() {
        String ip = Minecraft.getMinecraft().getCurrentServerData().serverIP;
        return (ip.equals("localhost") || ip.matches("(.+\\.)?(hypixel\\.net)(:25565)?"));
    }

    @Mod.EventHandler
    public void preInit(@NotNull FMLPreInitializationEvent event) {
        this.logger = event.getModLog();
        this.config = new ZombiesUtilsConfig(new Configuration(
                event.getSuggestedConfigurationFile())
        );
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        handlers = new Handlers();
        handlers.registerAll();
        CommandRegistry.registerAll();
        hotkeys.registerAll();
        gameData = new GameData();
    }

    public Logger getLogger() {
        return logger;
    }

    public Hotkeys getHotkeys() {
        return hotkeys;
    }

    public Handlers getHandlers() {
        return handlers;
    }

    public ZombiesUtilsConfig getConfig() {
        return config;
    }

    public GameManager getGameManager() {
        return gameManager;
    }

    public GameData getGameData() {
        return gameData;
    }
}
