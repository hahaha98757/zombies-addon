package xyz.stachel.zombiesutils.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.play.server.S1FPacketSetExperience;
import net.minecraft.network.play.server.S29PacketSoundEffect;
import net.minecraft.network.play.server.S32PacketConfirmTransaction;
import net.minecraft.network.play.server.S45PacketTitle;
import net.minecraft.util.ChatComponentText;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import xyz.stachel.zombiesutils.ZombiesUtils;
import xyz.stachel.zombiesutils.game.waves.WaveTiming;
import xyz.stachel.zombiesutils.timer.Timer;
import xyz.stachel.zombiesutils.utils.InvalidMapException;
import xyz.stachel.zombiesutils.utils.LanguageSupport;
import xyz.stachel.zombiesutils.utils.ScoardboardException;
import xyz.stachel.zombiesutils.utils.Scoreboard;

@Mixin(NetHandlerPlayClient.class)
public class MixinNetHandlerPlayClient {
    @Shadow
    private Minecraft gameController;
    @Unique
    private boolean zombies_utils$alienUfoOpened;

    @Inject(method = "handleSoundEffect", at = @At(value = "HEAD"))
    private void handleSound(S29PacketSoundEffect packetIn, CallbackInfo ci) {
        if (this.gameController.isCallingFromMinecraftThread()) {
            zombies_utils$handleSound(packetIn);
        }
    }

    @Inject(method = "handleTitle", at = @At(value = "HEAD"))
    private void handleTitle(S45PacketTitle packetIn, CallbackInfo ci) {
        if (this.gameController.isCallingFromMinecraftThread()) {
            zombies_utils$handleTitle(packetIn);
        }
    }

    @Inject(method = "handleConfirmTransaction", at = @At(value = "HEAD"))
    private void handleSetExperience(S32PacketConfirmTransaction packetIn, CallbackInfo ci) {
        if (this.gameController.isCallingFromMinecraftThread()) {
            zombies_utils$handleConfirmTransaction(packetIn);
        }
    }

    @Unique
    private void zombies_utils$handleSound(@NotNull S29PacketSoundEffect packet) {
        if (Scoreboard.isNotZombies()) return;
        final String soundEffect = packet.getSoundName();

        if (!(
                soundEffect.equals("mob.wither.spawn")
                        || (soundEffect.equals("mob.guardian.curse")
                        && !zombies_utils$alienUfoOpened)
        )) return;

        zombies_utils$alienUfoOpened = soundEffect.equals("mob.guardian.curse");

        try {
            ZombiesUtils.getInstance().getGameManager().splitOrNew(Scoreboard.getRound());
        } catch (ScoardboardException | InvalidMapException e) {
            Minecraft.getMinecraft().thePlayer.addChatMessage(new ChatComponentText("§cFailed to start or split timer. Please send a log to Stachelbeere1248."));
            ZombiesUtils.getInstance().getLogger().error(e.fillInStackTrace());
        }
    }

    @Unique
    private void zombies_utils$handleTitle(@NotNull S45PacketTitle packet) {
        if (packet.getType() != S45PacketTitle.Type.TITLE) return;
        if (Scoreboard.isNotZombies()) return;
        final String message = packet.getMessage().getUnformattedText().trim();
        String serverNumber;
        serverNumber = Scoreboard.getServerNumber().orElse("");
        if (LanguageSupport.isWin(message)) ZombiesUtils.getInstance().getGameManager().endGame(serverNumber, true);
        if (LanguageSupport.isLoss(message)) ZombiesUtils.getInstance().getGameManager().endGame(serverNumber, false);
    }

    @Unique
    private void zombies_utils$handleConfirmTransaction(@NotNull S32PacketConfirmTransaction packet) {
        if (packet.getWindowId() == 0) {
            Timer.runTick();
            WaveTiming.onTick();
        }
    }
}
