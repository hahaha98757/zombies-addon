package xyz.stachel.zombiesutils.timer.recorder;

public interface ISplitsData {
    String toJSON();
}
