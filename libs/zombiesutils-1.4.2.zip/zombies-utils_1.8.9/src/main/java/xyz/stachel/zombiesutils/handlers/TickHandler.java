package xyz.stachel.zombiesutils.handlers;

import xyz.stachel.zombiesutils.ZombiesUtils;
import xyz.stachel.zombiesutils.utils.Scoreboard;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.jetbrains.annotations.NotNull;

public class TickHandler {
    @SubscribeEvent
    public void onTick(TickEvent.@NotNull ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.START) return;
        Scoreboard.refresh();
        ZombiesUtils.getInstance().getHandlers().getRenderer().tick();
    }
}
