package xyz.stachel.zombiesutils.timer;

import xyz.stachel.zombiesutils.ZombiesUtils;
import xyz.stachel.zombiesutils.game.GameMode;
import xyz.stachel.zombiesutils.game.enums.Difficulty;
import xyz.stachel.zombiesutils.game.enums.Map;
import xyz.stachel.zombiesutils.game.windows.SLA;
import xyz.stachel.zombiesutils.handlers.Round1Correction;
import xyz.stachel.zombiesutils.timer.recorder.Category;
import xyz.stachel.zombiesutils.timer.recorder.files.CategoryFile;
import xyz.stachel.zombiesutils.timer.recorder.files.GameFile;
import xyz.stachel.zombiesutils.utils.Scoreboard;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;
import net.minecraftforge.common.MinecraftForge;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.jetbrains.annotations.NotNull;

public class Game {
    private final Timer timer;
    private final GameFile gameFile;
    private final boolean roundOneRecorded;
    private GameMode gameMode;
    private Category category;
    private int round;
    private boolean escaping;

    public Game(@NotNull final Map map, final String serverNumber) {
        this.gameMode = GameMode.getNormalForMap(map);
        this.timer = new Timer();
        this.gameFile = new GameFile(serverNumber, map);
        if (ZombiesUtils.isHypixel()) this.category = new Category();
        this.round = 1;
        this.roundOneRecorded = true;

        MinecraftForge.EVENT_BUS.register(new Round1Correction(this.timer, serverNumber));
        if (ZombiesUtils.getInstance().getConfig().isSlaToggled()) SLA.instance = new SLA(map);
    }

    public Game(@NotNull final Map map, final String serverNumber, final int round) {
        this.gameMode = GameMode.getNormalForMap(map);
        this.timer = new Timer();
        this.gameFile = new GameFile(serverNumber, map);
        if (ZombiesUtils.isHypixel()) this.category = new Category();
        this.round = round;
        this.roundOneRecorded = (round == 1);

        MinecraftForge.EVENT_BUS.register(new Round1Correction(this.timer, serverNumber));
        if (ZombiesUtils.getInstance().getConfig().isSlaToggled()) SLA.instance = new SLA(map);

    }

    public Timer getTimer() {
        return this.timer;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public void changeDifficulty(final Difficulty difficulty) {
        this.gameMode = this.gameMode.appliedDifficulty(difficulty);
    }

    public int getRound() {
        return round;
    }

    public GameMode getGameMode() {
        return gameMode;
    }

    public void pass(int round) {
        if ((round == 0) || (this.round == round + 1) || (this.timer.getRoundTime() < 100)) {
            ZombiesUtils.getInstance().getLogger().debug("SPLIT CANCELLED");
            return;
        }

        if (round == 1) {
            Scoreboard.getDifficulty().ifPresent(this::changeDifficulty);
        }

        if (ZombiesUtils.isHypixel()) try {
            record();
        } catch (ArrayIndexOutOfBoundsException e) {
            ZombiesUtils.getInstance().getLogger().error(ExceptionUtils.getStackTrace(e));
            Minecraft.getMinecraft().thePlayer.addChatMessage(new ChatComponentText("§cError recording splits"));
        }
        this.timer.split();
        this.round = round + 1;
    }

    public void helicopter() {
        if (!gameMode.isMap(Map.PRISON)) {
            Minecraft.getMinecraft().thePlayer.addChatMessage(new ChatComponentText("§cEscaping without playing prison???"));
            ZombiesUtils.getInstance().getLogger().error(Thread.currentThread().getStackTrace());
            return;
        }
        this.escaping = true;
        this.pass(30);
    }

    private void record() {
        this.compareSegment();
        if (this.roundOneRecorded) this.compareBest();
        this.gameFile.setSegment(this.round, this.timer.getRoundTime());
    }

    public void compareSegment() throws IndexOutOfBoundsException {
        if (this.escaping) return;
        final CategoryFile categoryFile = this.category.getByGameMode(this.gameMode);
        final short bestSegment = categoryFile.getBestSegment(round);
        final int roundTime = this.getTimer().getRoundTime();

        if (bestSegment == (short) 0) categoryFile.setBestSegment(round, roundTime);
        else if (roundTime < bestSegment) categoryFile.setBestSegment(round, roundTime);
        final RecordMessageSender recordMessageSender = new RecordMessageSender(this.category.getName(), round, roundTime, bestSegment);
        recordMessageSender.roundSplit();
        recordMessageSender.sendRecordMessage();
    }

    public void compareBest() throws IndexOutOfBoundsException {
        final CategoryFile categoryFile = this.category.getByGameMode(this.gameMode);
        final int round = this.escaping ? 31 : this.round;
        final int personalBest = categoryFile.getPersonalBest(round);
        final int gameTime = this.timer.getGameTime();

        if (personalBest == 0) categoryFile.setPersonalBest(round, gameTime);
        else if (gameTime < personalBest) categoryFile.setPersonalBest(round, gameTime);
        final RecordMessageSender recordMessageSender = new RecordMessageSender(category.getName(), round, gameTime, personalBest);
        if (!escaping) recordMessageSender.gameSplit();
        else recordMessageSender.helicopterSplit();
        recordMessageSender.sendRecordMessage();
    }
}
