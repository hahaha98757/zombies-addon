package xyz.stachel.zombiesutils.utils;

public class ServerWorldAbsoluteTicker {
    private static long ticks = 0;

    public static void setWorldTime(long ticks) {
        ServerWorldAbsoluteTicker.ticks = ticks;
    }

    public static void incrementWorldTime() {
        ServerWorldAbsoluteTicker.ticks += 1;
    }

    public static long getWorldTime() {
        return ServerWorldAbsoluteTicker.ticks;
    }
}
