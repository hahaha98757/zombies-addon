package xyz.stachel.zombiesutils.timer;

import xyz.stachel.zombiesutils.utils.ServerWorldAbsoluteTicker;

public class Timer {

    private long startTick;
    private int roundStart;

    public Timer() {
        this.startTick = this.getCurrentTick();
    }

    public void correctStartTick() {
        this.startTick = this.getCurrentTick() - 200;
    }

    void split() {
        this.roundStart = this.getGameTime();
    }

    public int getGameTime() {
        return (int) (getCurrentTick() - startTick);
    }

    public short getRoundTime() {
        return (short) (getGameTime() - roundStart);
    }

    private long getCurrentTick() {
        return ServerWorldAbsoluteTicker.getWorldTime();
    }
}
