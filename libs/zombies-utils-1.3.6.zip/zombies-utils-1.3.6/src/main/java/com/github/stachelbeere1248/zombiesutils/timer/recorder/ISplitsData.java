package com.github.stachelbeere1248.zombiesutils.timer.recorder;

public interface ISplitsData {
    String toJSON();
}
