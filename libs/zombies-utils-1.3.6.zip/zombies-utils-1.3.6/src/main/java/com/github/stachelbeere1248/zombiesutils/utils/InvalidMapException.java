package com.github.stachelbeere1248.zombiesutils.utils;

public class InvalidMapException extends Exception {
}
