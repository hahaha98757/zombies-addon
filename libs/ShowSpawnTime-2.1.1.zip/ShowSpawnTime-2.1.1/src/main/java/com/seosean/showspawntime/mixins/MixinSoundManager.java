package com.seosean.showspawntime.mixins;

import net.minecraft.client.audio.SoundManager;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(SoundManager.class)
public class MixinSoundManager {
}
